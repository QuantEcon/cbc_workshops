clear all

run Parameters.m
run TransitionMatrix.m

tic
run vfi_OER.m
toc